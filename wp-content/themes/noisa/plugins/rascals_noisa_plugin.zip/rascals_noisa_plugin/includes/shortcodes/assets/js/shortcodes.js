/**
 * Plugin Name: 	Rascals NOISA Plugin
 * Theme Author: 	Mariusz Rek - Rascals Themes
 * Theme URI: 		http://rascals.eu/noisa
 * Author URI: 		http://rascals.eu
 * File:			shortcodes.js
 * =========================================================================================================================================
 *
 * @package noisa-plugin
 * @since 1.0.0
 */

jQuery(document).ready(function($) {



});